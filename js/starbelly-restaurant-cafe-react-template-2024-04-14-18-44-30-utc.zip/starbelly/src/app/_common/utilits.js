export const closeAllModals = () => {
  
};