---
#preview
title: Nguta Ithya
avatar: /img/faces/4.jpg
---